'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { Pause, Play, RotateCcw, Sparkles, Waves } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import Challenge from './challenge';

type Boundary = 'fixed-fixed' | 'fixed-free';
const W = 960, H = 400, MID = 206, X0 = 54, X1 = 916, SPAN = X1 - X0;

function makePath(fn: (x: number) => number) {
  let d = '';
  for (let i = 0; i <= 240; i += 1) {
    const px = X0 + (i / 240) * SPAN;
    const py = MID - fn(i / 240);
    d += `${i ? 'L' : 'M'}${px.toFixed(2)},${py.toFixed(2)} `;
  }
  return d;
}

function makeLoopPath(fn: (x: number) => number, start: number, end: number) {
  const steps = 60;
  let d = '';
  for (let i = 0; i <= steps; i += 1) {
    const x = start + ((end - start) * i) / steps;
    d += `${i ? 'L' : 'M'}${(X0 + x * SPAN).toFixed(2)},${(MID - fn(x)).toFixed(2)} `;
  }
  for (let i = steps; i >= 0; i -= 1) {
    const x = start + ((end - start) * i) / steps;
    d += `L${(X0 + x * SPAN).toFixed(2)},${(MID + fn(x)).toFixed(2)} `;
  }
  return `${d}Z`;
}

export default function Home() {
  const [boundary, setBoundary] = useState<Boundary>('fixed-fixed');
  const [mode, setMode] = useState(2);
  const [frequency, setFrequency] = useState(2);
  const [driven, setDriven] = useState(true);
  const fundamental = boundary === 'fixed-fixed' ? 1 : 0.5;
  const resonance = boundary === 'fixed-fixed' ? mode : mode - 0.5;
  const nearestMode = Math.max(1, Math.min(6, Math.round(frequency + (boundary === 'fixed-free' ? 0.5 : 0))));
  const nearestFrequency = boundary === 'fixed-fixed' ? nearestMode : nearestMode - 0.5;
  const tuned = Math.abs(frequency - nearestFrequency) < 0.005;
  const [amplitude, setAmplitude] = useState(62);
  const [rate, setRate] = useState(0.7);
  const [running, setRunning] = useState(true);
  const [components, setComponents] = useState(false);
  const [labels, setLabels] = useState(true);
  const [probeX, setProbeX] = useState(0.28);
  const [time, setTime] = useState(0);
  const last = useRef<number | null>(null);

  useEffect(() => {
    let frame = 0;
    const tick = (now: number) => {
      if (last.current === null) last.current = now;
      const dt = Math.min((now - last.current) / 1000, 0.05);
      last.current = now;
      if (running) setTime((value) => value + dt * rate);
      frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [running, rate]);

  useEffect(() => {
    type ToolInput = { boundary: Boundary; mode: number; amplitude: number; showComponents?: boolean };
    type ModelContext = { registerTool: (tool: object, options?: { signal?: AbortSignal }) => void | Promise<void> };
    const context = (document as unknown as { modelContext?: ModelContext }).modelContext;
    if (!context?.registerTool) return;
    const lifecycle = new AbortController();
    const registration = context.registerTool({
      name: 'configure_standing_wave',
      title: '設定駐波實驗',
      description: '設定邊界條件、模式、振幅，並更新畫面上的駐波模擬。',
      inputSchema: {
        type: 'object',
        properties: {
          boundary: { type: 'string', enum: ['fixed-fixed', 'fixed-free'] },
          mode: { type: 'integer', minimum: 1, maximum: 6 },
          amplitude: { type: 'number', minimum: 28, maximum: 94 },
          showComponents: { type: 'boolean' },
        },
        required: ['boundary', 'mode', 'amplitude'],
        additionalProperties: false,
      },
      annotations: { readOnlyHint: false, untrustedContentHint: false },
      execute(input: ToolInput) {
        if (!['fixed-fixed', 'fixed-free'].includes(input.boundary) || !Number.isInteger(input.mode) || input.mode < 1 || input.mode > 6 || !Number.isFinite(input.amplitude) || input.amplitude < 28 || input.amplitude > 94) {
          throw new Error('設定值超出模擬可用範圍。');
        }
        setBoundary(input.boundary); setMode(input.mode); setAmplitude(input.amplitude); setDriven(false);
        if (typeof input.showComponents === 'boolean') setComponents(input.showComponents);
        setTime(0);
        return { applied: true, boundary: input.boundary, mode: input.mode, amplitude: input.amplitude, showComponents: input.showComponents ?? false };
      },
    }, { signal: lifecycle.signal });
    void Promise.resolve(registration).catch(() => undefined);
    return () => lifecycle.abort();
  }, []);

  const waveModel = useMemo(() => {
    const selectedMode = driven ? nearestMode : mode;
    const factor = boundary === 'fixed-fixed' ? selectedMode : selectedMode - 0.5;
    const k = factor * Math.PI;
    // Steady-state modal response to a small transverse point force at x=0.17L.
    // L=1 m, v=2 m/s, modal loss term 0.04*f in frequency-squared units.
    const terms = Array.from({ length: 24 }, (_, i) => {
      const q = boundary === 'fixed-fixed' ? i + 1 : i + 0.5;
      const detuning = q * q - frequency * frequency;
      const loss = 0.04 * frequency;
      const force = 0.12 * Math.sin(q * Math.PI * 0.17);
      const denominator = detuning * detuning + loss * loss;
      return { q, real: force * detuning / denominator, imaginary: force * loss / denominator };
    });
    const coefficients = (x: number) => terms.reduce((sum, term) => {
      const shape = Math.sin(term.q * Math.PI * x);
      return { real: sum.real + shape * term.real, imaginary: sum.imaginary + shape * term.imaginary };
    }, { real: 0, imaginary: 0 });
    const envelope = (x: number) => {
      if (!driven) return amplitude * Math.abs(Math.sin(k * x));
      const c = coefficients(x);
      return amplitude * Math.hypot(c.real, c.imaginary);
    };
    const nodes = boundary === 'fixed-fixed'
      ? Array.from({ length: selectedMode + 1 }, (_, i) => i / selectedMode)
      : Array.from({ length: selectedMode }, (_, i) => (2 * i) / (2 * selectedMode - 1));
    const antinodes = boundary === 'fixed-fixed'
      ? Array.from({ length: selectedMode }, (_, i) => (2 * i + 1) / (2 * selectedMode))
      : Array.from({ length: selectedMode }, (_, i) => (2 * i + 1) / (2 * selectedMode - 1));
    const boundaries = boundary === 'fixed-fixed' ? nodes : [...nodes, 1];
    const loopSegments = boundaries.slice(0, -1).map((start, i) => ({ start, end: boundaries[i + 1] }));
    return { factor, k, coefficients, envelope, nodes, antinodes, loopSegments };
  }, [amplitude, boundary, mode, driven, frequency, nearestMode]);

  const values = useMemo(() => {
    const actualFrequency = driven ? frequency : resonance;
    const phase = 2 * Math.PI * actualFrequency * time;
    const displacement = (x: number, t: number) => {
      const p = 2 * Math.PI * actualFrequency * t;
      if (!driven) return amplitude * Math.sin(waveModel.k * x) * Math.cos(p);
      const c = waveModel.coefficients(x);
      return amplitude * (c.real * Math.cos(p) + c.imaginary * Math.sin(p));
    };
    const standing = (x: number) => displacement(x, time);
    const incident = (x: number) => amplitude * 0.5 * Math.sin(waveModel.k * x - phase);
    const reflected = (x: number) => amplitude * 0.5 * Math.sin(waveModel.k * x + phase);
    return { factor: waveModel.factor, standing, displacement, incident, reflected,
      nodes: driven ? [] : waveModel.nodes, antinodes: driven ? [] : waveModel.antinodes,
      lambda: 2 / actualFrequency };
  }, [amplitude, time, driven, frequency, resonance, waveModel]);

  const showLoops = !driven || tuned;
  const loopPaths = useMemo(
    () => waveModel.loopSegments.map(({ start, end }) => makeLoopPath(waveModel.envelope, start, end)),
    [waveModel],
  );
  const standingPath = makePath(values.standing);

  const probeAmplitude = Math.abs(amplitude * Math.sin(values.factor * Math.PI * probeX));
  const probeDisplacement = values.standing(probeX);
  let particlePath = '';
  for (let i = 0; i <= 120; i += 1) {
    const px = 12 + (i / 120) * 936;
    const py = 85 - values.displacement(probeX, time - 1 + i / 120) * 0.52;
    particlePath += `${i ? 'L' : 'M'}${px.toFixed(2)},${py.toFixed(2)} `;
  }

  function reset() {
    setBoundary('fixed-fixed'); setMode(2); setAmplitude(62); setRate(0.7);
    setFrequency(2); setDriven(true);
    setProbeX(0.28); setTime(0); setRunning(true); setComponents(false); setLabels(true);
  }

  return (
    <main className="min-h-screen bg-[var(--background)] text-[var(--foreground)]">
      <header className="border-b border-white/10 px-5 py-4 sm:px-8">
        <div className="mx-auto flex max-w-[1480px] items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-cyan-300 text-slate-950 shadow-[0_0_28px_rgba(103,232,249,.22)]"><Waves aria-hidden="true" size={23} strokeWidth={2.4} /></div>
            <div><p className="text-xs font-semibold tracking-[.18em] text-cyan-300">PHYSICS LAB · 5.4</p><h1 className="text-xl font-semibold tracking-tight sm:text-2xl">駐波實驗室</h1></div>
          </div>
          <Button variant="outline" size="sm" onClick={reset} className="border-white/15 bg-white/5 text-slate-200 hover:bg-white/10 hover:text-white"><RotateCcw aria-hidden="true" /> 重設</Button>
        </div>
      </header>

      <Tabs defaultValue="lab">
      <TabsList className="mx-auto mt-5 h-12!"><TabsTrigger value="lab" className="px-6">自由實驗</TabsTrigger><TabsTrigger value="game" className="px-6">計算挑戰</TabsTrigger></TabsList>
      <TabsContent value="game" keepMounted><Challenge /></TabsContent>
      <TabsContent value="lab">
      <div className="mx-auto grid max-w-[1480px] gap-5 px-4 py-5 lg:grid-cols-[minmax(0,1fr)_320px] lg:px-8">
        <section className="min-w-0 space-y-5">
          <section className="panel" aria-live="polite">
            <h2>{driven ? (tuned ? `共振：f = ${frequency.toFixed(2)} Hz，出現清晰的駐波波圈` : `f = ${frequency.toFixed(2)} Hz：未對準共振頻率`) : '理想駐波：觀察波節、波腹及疊加'}</h2>
            <p className="mt-2 text-sm text-slate-300">{driven ? `最近的固有頻率是 ${nearestFrequency.toFixed(2)} Hz。慢慢調整 f，觀察振幅如何在附近增大。` : '切換回頻率實驗，可比較共振與非共振的振動。'}</p>
            <p className="mt-2 text-sm text-slate-400">繩長 L = 1 m，波速 v = 2 m/s。{boundary === 'fixed-fixed' ? '兩端固定：fₙ = nv/(2L) = n Hz。' : '一端自由：fₙ = (2n−1)v/(4L) = (2n−1) × 0.5 Hz。'}</p>
          </section>
          <div className="overflow-hidden rounded-[28px] border border-white/10 bg-[linear-gradient(145deg,rgba(13,31,54,.94),rgba(5,14,27,.98))] shadow-2xl shadow-black/20">
            <div className="flex flex-wrap items-start justify-between gap-3 border-b border-white/10 px-5 py-4 sm:px-7">
              <div><p className="mb-1 text-xs font-semibold uppercase tracking-[.16em] text-cyan-300">即時波形</p><h2 className="text-lg font-semibold sm:text-xl">{driven ? '調整頻率，尋找共振' : '兩列相反方向的波互相疊加'}</h2><p className="mt-1 text-sm text-slate-400">{showLoops ? '淡色波圈與虛線是最大位移範圍；亮線是此刻的繩形。按一下繩子可觀察粒子的振動。' : '按一下繩子任何位置，觀察該粒子的振動。'}</p></div>
              <div className="flex flex-wrap gap-2 text-sm"><span className="legend-pill"><i className="bg-cyan-300" />此刻繩形</span>{showLoops && <span className="legend-pill"><i className="bg-violet-300" />波圈範圍</span>}{components && !driven && <><span className="legend-pill"><i className="bg-fuchsia-400" />入射波</span><span className="legend-pill"><i className="bg-amber-300" />反射波</span></>}</div>
            </div>

            <div className="relative">
              <svg viewBox={`0 0 ${W} ${H}`} role="img" aria-label={driven ? `驅動頻率 ${frequency} Hz 的受迫振動${showLoops ? '，顯示波圈最大位移輪廓' : ''}` : `第 ${mode} 模式駐波動畫，顯示波圈、波節、波腹和所選粒子`} className="block aspect-[12/5] min-h-[300px] w-full cursor-crosshair"
                onPointerDown={(event) => { const box = event.currentTarget.getBoundingClientRect(); const x = (event.clientX - box.left) / box.width; setProbeX(Math.max(0, Math.min(1, (x * W - X0) / SPAN))); }}>
                <defs><linearGradient id="wave" x1="0" x2="1"><stop offset="0" stopColor="#67e8f9" /><stop offset=".5" stopColor="#e0f2fe" /><stop offset="1" stopColor="#67e8f9" /></linearGradient><filter id="glow"><feGaussianBlur stdDeviation="5" result="b" /><feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge></filter></defs>
                {Array.from({ length: 9 }, (_, i) => <line key={i} x1={X0 + (i / 8) * SPAN} x2={X0 + (i / 8) * SPAN} y1="50" y2="350" stroke="rgba(148,163,184,.08)" />)}
                {[86, MID, 326].map((y) => <line key={y} x1={X0} x2={X1} y1={y} y2={y} stroke={y === MID ? 'rgba(148,163,184,.34)' : 'rgba(148,163,184,.08)'} strokeDasharray={y === MID ? '6 7' : undefined} />)}
                {showLoops && loopPaths.map((path, i) => <path key={`loop-${i}`} d={path} fill={i % 2 === 0 ? '#22d3ee' : '#a78bfa'} fillOpacity=".18" stroke={i % 2 === 0 ? '#67e8f9' : '#c4b5fd'} strokeOpacity=".75" strokeWidth="2.5" strokeDasharray="9 8" />)}
                <line x1={X0} x2={X0} y1="60" y2="352" stroke="#64748b" strokeWidth="5" strokeLinecap="round" />
                {boundary === 'fixed-fixed' ? <line x1={X1} x2={X1} y1="60" y2="352" stroke="#64748b" strokeWidth="5" strokeLinecap="round" /> : <circle cx={X1} cy={MID} r="11" fill="#081629" stroke="#fbbf24" strokeWidth="4" />}
                {components && !driven && <><path d={makePath(values.incident)} fill="none" stroke="#e879f9" strokeWidth="2.5" strokeDasharray="8 7" opacity=".82" /><path d={makePath(values.reflected)} fill="none" stroke="#fde047" strokeWidth="2.5" strokeDasharray="8 7" opacity=".82" /></>}
                <path d={standingPath} fill="none" stroke="#67e8f9" strokeWidth="12" opacity=".2" filter="url(#glow)" /><path d={standingPath} fill="none" stroke="url(#wave)" strokeWidth="5" strokeLinecap="round" />
                {values.nodes.map((x, i) => <g key={`n${i}`}><circle cx={X0 + x * SPAN} cy={MID} r="7" fill="#071525" stroke="#fb7185" strokeWidth="3" />{labels && <text x={X0 + x * SPAN} y="374" textAnchor="middle" className="node-label">波節</text>}</g>)}
                {values.antinodes.map((x, i) => labels && <g key={`a${i}`}><line x1={X0 + x * SPAN} x2={X0 + x * SPAN} y1={MID - amplitude - 18} y2={MID + amplitude + 18} stroke="rgba(103,232,249,.22)" strokeDasharray="4 5" /><text x={X0 + x * SPAN} y={Math.max(35, MID - amplitude - 26)} textAnchor="middle" className="antinode-label">波腹</text></g>)}
                <line x1={X0 + probeX * SPAN} x2={X0 + probeX * SPAN} y1="56" y2="352" stroke="rgba(255,255,255,.28)" strokeDasharray="3 6" /><circle cx={X0 + probeX * SPAN} cy={MID - probeDisplacement} r="9" fill="#fff" stroke="#22d3ee" strokeWidth="4" />
              </svg>
              <div className="absolute bottom-3 left-4 rounded-lg border border-white/10 bg-slate-950/75 px-3 py-2 text-xs text-slate-300 backdrop-blur sm:left-6">白點：所選粒子 · x = {probeX.toFixed(2)}L</div>
            </div>

            <div className="grid gap-4 border-t border-white/10 p-5 sm:grid-cols-3 sm:p-7">
              <div className="control-block sm:col-span-2"><div className="mb-3 flex items-center justify-between"><label htmlFor="amplitude">{driven ? '驅動力大小（相對值）' : '振幅'}</label><output>{Math.round(amplitude / 12)} 格</output></div><Slider id="amplitude" min={28} max={94} step={2} value={[amplitude]} onValueChange={(next) => setAmplitude(Array.isArray(next) ? next[0] : next)} aria-label="調整振幅" /></div>
              <Button onClick={() => setRunning((value) => !value)} className="h-12 self-end bg-cyan-300 font-semibold text-slate-950 hover:bg-cyan-200">{running ? <Pause aria-hidden="true" /> : <Play aria-hidden="true" />} {running ? '暫停動畫' : '播放動畫'}</Button>
            </div>
          </div>

          <h2 className="text-lg font-semibold">理想駐波的特性</h2><div className="grid gap-4 md:grid-cols-3">
            <article className="concept-card"><span className="concept-number">01</span><h3>波節保持靜止</h3><p>入射波和反射波在這些位置總是反相，位移互相抵消。</p></article>
            <article className="concept-card"><span className="concept-number">02</span><h3>波腹振幅最大</h3><p>相鄰波節的正中間是波腹；相鄰波節距離等於 ½λ。</p></article>
            <article className="concept-card"><span className="concept-number">03</span><h3>波形不會前進</h3><p>駐波儲存能量，但不會把能量由繩子一端傳送到另一端。</p></article>
          </div>
        </section>

        <aside className="space-y-4">
          <section className="panel">
            <div className="mb-5 flex items-center gap-2"><Sparkles className="text-cyan-300" size={18} /><h2>實驗控制台</h2></div>
            <label className="switch-row mb-5"><span><b>頻率實驗</b><small>關閉後查看理想駐波及兩波疊加</small></span><Switch checked={driven} onCheckedChange={(value) => { setDriven(value); setComponents(false); setTime(0); }} aria-label="頻率實驗" /></label>
            {driven && <div className="mb-5">
              <label className="flex items-center justify-between gap-3">驅動頻率 f（Hz）<input aria-label="驅動頻率數值" type="number" min="0.25" max="6" step="0.01" value={frequency} className="w-24 rounded border border-cyan-300/30 bg-slate-950 p-2" onChange={(e) => { const value = e.currentTarget.valueAsNumber; if (Number.isFinite(value) && value >= 0.25 && value <= 6) { setFrequency(value); setTime(0); } }} /></label>
              <div className="my-4"><Slider min={0.25} max={6} step={0.01} value={[frequency]} onValueChange={(next) => { setFrequency(Array.isArray(next) ? next[0] : next); setTime(0); }} aria-label="驅動頻率" /></div>
              <p className="mb-2 text-sm text-slate-300">點選一個共振頻率：</p>
              <div className="grid grid-cols-3 gap-2">{Array.from({ length: 6 }, (_, i) => { const f = boundary === 'fixed-fixed' ? i + 1 : i + 0.5; return <Button key={f} variant="outline" onClick={() => { setFrequency(f); setTime(0); }} className={Math.abs(frequency-f)<0.005 ? 'bg-cyan-300 text-slate-950' : ''}>{f} Hz</Button>; })}</div>
              <p className="mt-3 text-sm text-slate-400">試比較 2.00 Hz 與 2.30 Hz（兩端固定）。動畫速度只改變播放快慢，不改變 f。</p>
            </div>}
            <fieldset><legend>邊界條件</legend><div className="segmented"><button className={boundary === 'fixed-fixed' ? 'active' : ''} onClick={() => setBoundary('fixed-fixed')}>兩端固定</button><button className={boundary === 'fixed-free' ? 'active' : ''} onClick={() => setBoundary('fixed-free')}>一端自由</button></div></fieldset>
            {!driven && <fieldset className="mt-6"><div className="mb-3 flex items-center justify-between"><legend>波圈／模式</legend><output className="mode-output">n = {mode}</output></div><Slider min={1} max={6} step={1} value={[mode]} onValueChange={(next) => { setMode(Array.isArray(next) ? next[0] : next); setTime(0); }} aria-label="調整駐波模式" /><div className="mt-2 flex justify-between text-xs text-slate-500"><span>基頻</span><span>第 6 模式</span></div></fieldset>}
            <fieldset className="mt-6"><div className="mb-3 flex items-center justify-between"><legend>動畫速度</legend><output>{rate.toFixed(1)}×</output></div><Slider min={0.2} max={1.8} step={0.1} value={[rate]} onValueChange={(next) => setRate(Array.isArray(next) ? next[0] : next)} aria-label="調整動畫速度" /></fieldset>
            <div className="mt-6 space-y-4 border-t border-white/10 pt-5"><label className="switch-row"><span><b>顯示兩列行波</b><small>看見疊加的來源</small></span><Switch disabled={driven} checked={components && !driven} onCheckedChange={setComponents} aria-label="顯示入射波和反射波" /></label><label className="switch-row"><span><b>顯示標記</b><small>波節與波腹</small></span><Switch disabled={driven} checked={labels && !driven} onCheckedChange={setLabels} aria-label="顯示波節和波腹標記" /></label></div>
          </section>
          <section className="panel formula-panel"><p className="eyebrow">目前讀數 · v = fλ</p><div className="formula">λ = <strong>{values.lambda.toFixed(2)} m</strong></div><div className="formula">f = <strong>{(driven ? frequency : resonance).toFixed(2)} Hz</strong></div><p className="formula-note">基頻 f₁ = {fundamental} Hz</p></section>
          {driven && <section className="panel"><h2>為甚麼只在特定頻率出現？</h2><p className="mt-2 text-sm leading-6 text-slate-300">波來回反射，只有符合邊界條件的頻率才能有效累積振動能量，形成明顯的駐波波圈。非共振時仍會振動，但振幅通常較小。</p><p className="mt-2 text-sm leading-6 text-slate-400">這裡模擬繩上 0.17L 處受到小週期力的有阻尼穩態響應。真實共振有頻寬，並非偏離一點便完全沒有波。波節／波腹的精確標記及等振幅兩波疊加，請在「理想駐波」查看。</p></section>}
          <section className="panel particle-panel"><div className="mb-3 flex items-end justify-between"><div><p className="eyebrow">所選粒子</p><h2>位移—時間圖</h2></div><span className="phase-badge">{driven ? `位移 ${(probeDisplacement / 12).toFixed(1)} 格` : `振幅 ${Math.round(probeAmplitude / 12)} 格`}</span></div><svg viewBox="0 0 960 170" className="w-full" role="img" aria-label="所選粒子的位移時間圖"><line x1="12" x2="948" y1="85" y2="85" stroke="rgba(148,163,184,.35)" strokeDasharray="5 6" /><path d={particlePath} /></svg><p className="text-sm leading-6 text-slate-400">{driven ? '顯示此粒子最近 1 秒的位移。共振時振幅較大；有阻尼時各處相位可能不同。' : '同一波圈內的粒子同相振動；相鄰波圈內的粒子則反相振動。'}</p></section>
        </aside>
      </div>
      </TabsContent>
      </Tabs>
    </main>
  );
}
