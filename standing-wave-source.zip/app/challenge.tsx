'use client';
import { useState } from 'react';
import { Button } from '@/components/ui/button';

const rounds = [
  { title: '找出波長', prompt: '兩端固定的繩子長 1.2 m，形成 3 個波圈。波長 λ 是多少？', unit: 'm', answer: 0.8, hint: '一個波圈長度是半個波長：L = nλ/2。', solution: 'λ = 2L/n = 2 × 1.2 ÷ 3 = 0.8 m。', n: 3, free: false },
  { title: '調準共振頻率', prompt: '兩端固定的繩子長 0.75 m，波速為 12 m/s。要形成 2 個波圈，驅動頻率 f 應是多少？', unit: 'Hz', answer: 16, hint: '先用 λ = 2L/n 求波長，再用 f = v/λ。', solution: 'λ = 2 × 0.75 ÷ 2 = 0.75 m；f = 12 ÷ 0.75 = 16 Hz。', n: 2, free: false },
  { title: '波節之間', prompt: '波速為 6 m/s，駐波頻率為 10 Hz。相鄰兩個波節相距多少？', unit: 'm', answer: 0.3, hint: '相鄰波節的距離是 λ/2，而不是 λ。', solution: 'λ = v/f = 6 ÷ 10 = 0.6 m；波節間距 = λ/2 = 0.3 m。', n: 3, free: false },
  { title: '頻率加倍', prompt: '同一條兩端固定的繩子在 20 Hz 時有 3 個波圈。保持繩長與波速不變，40 Hz 時有多少個波圈？', unit: '個', answer: 6, hint: '固定 L 和 v 時，fₙ = nf₁，因此波圈數與頻率成正比。', solution: 'n₂ = n₁ × f₂/f₁ = 3 × 40/20 = 6 個。波速不變，波長減半。', n: 6, free: false },
  { title: '自由端加分題', prompt: '一端固定、一端自由的繩子長 0.6 m，波速為 4.8 m/s。第二個振動模式的頻率是多少？', unit: 'Hz', answer: 6, hint: '固定—自由邊界只有奇數倍基頻：fₙ = (2n−1)v/(4L)。', solution: 'f₁ = 4.8 ÷ (4 × 0.6) = 2 Hz；第二個模式 f₂ = 3f₁ = 6 Hz，並不是 2f₁。', n: 2, free: true },
];

export default function Challenge() {
  const [index, setIndex] = useState(0);
  const [answer, setAnswer] = useState('');
  const [attempts, setAttempts] = useState(0);
  const [hint, setHint] = useState(false);
  const [resolved, setResolved] = useState(false);
  const [revealed, setRevealed] = useState(false);
  const [feedback, setFeedback] = useState('');
  const [scores, setScores] = useState<number[]>([]);
  const [finished, setFinished] = useState(false);
  const q = rounds[index];
  const score = scores.reduce((a, b) => a + b, 0);
  const restart = () => { setIndex(0); setAnswer(''); setAttempts(0); setHint(false); setResolved(false); setRevealed(false); setFeedback(''); setScores([]); setFinished(false); };
  function submit(event: React.FormEvent) {
    event.preventDefault();
    if (resolved) return;
    const value = Number(answer.trim());
    if (!answer.trim() || !Number.isFinite(value) || value <= 0) { setFeedback('請輸入大於 0 的有效數值。'); return; }
    if (Math.abs(value - q.answer) <= Math.max(0.0001, q.answer * 0.005)) {
      const points = attempts === 0 && !hint ? 20 : 10;
      setScores([...scores, points]); setResolved(true); setFeedback(`答對了！獲得 ${points} 分。`);
    } else { setAttempts(attempts + 1); setFeedback('還未正確。檢查半波長、單位，以及題目的邊界條件，再試一次。'); }
  }
  const shape = Array.from({ length: 161 }, (_, i) => `${i ? 'L' : 'M'}${20+i*3.5},${85-48*Math.sin((q.free ? q.n-0.5 : q.n)*Math.PI*i/160)}`).join(' ');
  return <section className="mx-auto max-w-3xl px-4 py-6 text-base">
    <div className="panel space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3"><h2 className="text-xl!">駐波計算挑戰</h2><span className="text-cyan-300">{score} / 100 分 · {finished ? '完成' : `第 ${index+1} / 5 關`}</span></div>
      <p className="text-slate-300">每關首次答對得 20 分；使用提示或重試後答對得 10 分；查看答案得 0 分。沒有計時，先計算再提交。</p>
      {finished ? <div className="space-y-4"><h3 className="text-2xl">{score >= 80 ? '駐波解題高手！' : '完成五關，繼續練習！'}</h3><p>總分 {score} / 100。記住：先判斷邊界條件，再用波長關係及 v = fλ。</p><ol className="space-y-3">{rounds.map((item, i) => <li key={item.title} className="rounded-lg bg-slate-950/50 p-3"><b>{i+1}. {item.title} · {scores[i]} 分</b><p className="mt-1 text-slate-300">{item.solution}</p></li>)}</ol><Button onClick={restart}>重新挑戰</Button></div> : <>
        <h3 className="text-xl font-semibold">{q.title}</h3><p className="text-lg leading-8">{q.prompt}</p>
        <form onSubmit={submit} className="flex flex-wrap items-end gap-3" noValidate>
          <label className="grid gap-2">你的答案（{q.unit}）<input autoComplete="off" inputMode="decimal" type="number" step="any" value={answer} disabled={resolved} onChange={e=>setAnswer(e.target.value)} aria-label={`你的答案（${q.unit}）`} className="min-w-0 w-44 rounded-lg border border-cyan-300/40 bg-slate-950 p-3" /></label>
          <Button type="submit" disabled={resolved} className="h-12">提交答案</Button>
          <Button type="button" variant="outline" disabled={resolved || hint} onClick={()=>setHint(true)}>給我提示</Button>
        </form>
        <p className="text-sm text-slate-400">以指定單位輸入數值，接受 ±0.5% 的四捨五入誤差。</p>
        {hint && <p className="rounded-lg bg-amber-300/10 p-4 text-amber-200">提示：{q.hint}</p>}
        <p role="status" className={resolved ? 'text-cyan-300' : 'text-amber-200'}>{feedback}</p>
        {!resolved && attempts > 0 && <Button variant="outline" onClick={()=>{ setResolved(true); setRevealed(true); setScores([...scores,0]); setFeedback('本關查看答案，不計分。閱讀解法後再繼續。'); }}>查看解法（0 分）</Button>}
        {resolved && <div className="space-y-3 rounded-xl border border-cyan-300/20 bg-cyan-300/5 p-4"><h4 className="font-semibold">{revealed ? '一起解題' : '解題步驟'}</h4><p className="leading-7">{q.solution}</p><svg viewBox="0 0 600 170" role="img" aria-label={`${q.free ? '固定端與自由端' : '兩端固定'}的第 ${q.n} 模式示意`} className="w-full"><line x1="20" x2="580" y1="85" y2="85" stroke="#64748b" strokeDasharray="5 5"/><path d={shape} fill="none" stroke="#67e8f9" strokeWidth="3"/><circle cx="20" cy="85" r="5" fill="#fb7185"/>{!q.free && <circle cx="580" cy="85" r="5" fill="#fb7185"/>}</svg><p className="text-sm text-slate-400">模式示意圖（非按比例；第 3 關的波圈總數未有指定）。</p><Button onClick={()=>{ if(index===4){setFinished(true);return;} setIndex(index+1);setAnswer('');setAttempts(0);setHint(false);setResolved(false);setRevealed(false);setFeedback(''); }}>{index===4?'查看總成績':'下一關'}</Button></div>}
      </>}
    </div>
  </section>;
}
