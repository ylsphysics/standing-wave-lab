import type { NextConfig } from 'next';

const isGitHubPagesBuild = process.env.GITHUB_PAGES === 'true';

const nextConfig: NextConfig = isGitHubPagesBuild
  ? {
      output: 'export',
      basePath: '/standing-wave-lab',
      trailingSlash: true,
    }
  : {};

export default nextConfig;
