import { createRoot } from 'react-dom/client';
import Home from './app/page';
import './app/globals.css';

const root = document.getElementById('root');

if (!root) {
  throw new Error('找不到模擬器的頁面容器。');
}

createRoot(root).render(<Home />);
