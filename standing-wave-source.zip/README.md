# 駐波實驗室

互動式駐波物理模擬及計算挑戰，供學生探索共振頻率、波長、波節與波腹。

網站：https://ylsphysics.github.io/standing-wave-lab/

GitHub Pages 會以 GitHub Actions 建置並發佈。完整網站原始碼放在 `standing-wave-source.zip`；更新原始碼後替換該壓縮檔並推送至 `main`，即可觸發重新部署。
